
names(baseline)[names(baseline) == "ID"] <- "SEQN"
baseline <- subset(baseline,select = c('SEQN','WTMEC2YR','SDMVSTRA','SDMVPSU'))


data$SEQN <- rownames(data)

a <- merge(data,data_TST,by='SEQN')
ttt <- merge(a,baseline,by='SEQN')

sum(is.na(ttt))
colnames(data)

ttt <- na.omit(ttt)   #4006

save(ttt,file = '激素_ttt.RData')    ###合并'WTMEC2YR','SDMVSTRA','SDMVPSU'  周期是2013-2014,2015-2016




colnames(data_breast)
data <- merge(data_breast,baseline,by = 'SEQN')
rm(baseline,data_breast)

data <- merge(data,data_TST,by = 'SEQN')

rm(data_TST)

table(data$breast,data$MCQ220)

rownames(data) <- data$SEQN
data <- data[,-1]

unique(data$Gender)

data$Gender <- as.character(data$Gender)

data <- data[data$Gender == 'Female', ]

data <- data[data$Age > 20, ]

data$WWI <- data$WAI/sqrt(data$WEIGHT)

data <- data[!is.na(data$WWI), ]


#########################################
colnames(data)
df <- data[c("WWI","WAI","WEIGHT","BMI","HIGHT")]

save(df,file = 'WWIBMIWEIGHT.RData')


#################################################

save(data,file = 'D01_RawData.RData')

######


library(tableone)
## PS matching
library(Matching)
## Weighted analysis
library(survey)
library(reshape2)
library(ggplot2)
library(tidyverse)
library(mice)
library(ggplot2)
library(ggpubr)
library(tidyverse)
library(gtsummary)


colnames(data)

data_table01 <- subset(data,select = c("breast","Age","Race","Edu","PIR","Marry","Drink", ## baseline 01
                                       "Hypertension","Diabetes","CHD","HF","WWI"))

data_table01 <- data_table01[!is.na(data_table01$breast), ]
table(data$breast)
rm(data_table01)

######
data$Age_group <- ifelse(data$Age < 60,'< 60','≥ 60')
data$PIR_group <- '1.30–3.50'
data$PIR_group[which(data$PIR < 1.3)] <- '<1.30'
data$PIR_group[which(data$PIR >= 3.50)] <- '>= 3.50'
data$PIR_group <- factor(data$PIR_group,levels = c('<1.30','1.30–3.50','>= 3.50'),ordered = T)

data$Marry <- as.character(data$Marry)
table(data$Marry)
data$Marry <- ifelse(data$Marry == 'yes','Married','Never-married')
data$Drink <- as.character(data$Drink)
data$Drink <- ifelse(data$Drink == 'yes','Drinking','Non-drinking')
data$breast <- factor(data$breast,levels = c(0,1),labels = c('Control','Breast cancer'))
data$HF <- as.character(data$HF)
data$HF <- factor(data$HF,levels = c('Heart_failure','Health'),labels = c('Heart Failure','Health'),ordered = T)

data <- subset(data,select = c("breast","Age",'Age_group',"Race","Edu","PIR_group","Marry","Drink",
                                       "Hypertension","Diabetes","CHD","HF","WWI"))

colnames(data)[2] <- 'Age, years'
colnames(data)[3] <- 'Age, n(%)'
colnames(data)[4] <- 'Race, n(%)'
colnames(data)[5] <- 'Education, n(%)'
colnames(data)[6] <- 'Poverty-to-income ratio, n(%)'
colnames(data)[7] <- 'Marital status, n(%)'
colnames(data)[8] <- 'Alcohol drinking, n (%)'
# colnames(data)[9] <- 'Smoking status, n (%)'
colnames(data)[9] <- 'Hypertension, n (%)'
colnames(data)[10] <- 'Diabetes, n (%)'
colnames(data)[11] <- 'CHD, n (%)'
colnames(data)[12] <- 'Heart Failure, n (%)'

data <- na.omit(data)

tb <- data %>%
  tbl_summary(by = breast,
              statistic = list(
                all_continuous() ~ "{mean} ({sd})", #连续变量
                all_categorical() ~ "{n} ({p}%)"   #分类变量
              )) %>%
  add_p(pvalue_fun = ~ style_pvalue(.x, digits = 2)) %>% #指定了P值的显示格式为保留两位小数
  add_overall() %>%  #添加总体统计信息
  # add_n() %>%  #添加样本量
  modify_header(label ~ "**Variable**") %>% #修改表头标签格式
  # modify_spanning_header(c("stat_1", "stat_2") ~ "**Breast Cancer**") %>%  #合并列头
  modify_footnote(  #添加脚注说明数据格式
    all_stat_cols() ~ "Mean (sd) or Frequency (%)" 
  ) %>%
  modify_caption("**Table 1. Baseline characteristics of participants by breast cancer status**") %>% #修改表格标题
  bold_labels() 

print(tb)

save(data,file = 'D02_CleanData_Before_PSM.RData')

#####

colnames(data)

data$breast <- as.character(data$breast)
data$breast <- ifelse(data$breast == 'Breast cancer',1,0)



colnames(data)

data_table01 <- subset(data,select = c("breast","Age","Race","Edu","PIR","Marry","Drink", ## baseline 01
                                       "Hypertension","Diabetes","CHD","HF","WWI"))

data_table01 <- data_table01[!is.na(data_table01$breast), ]
table(data$breast)
rm(data_table01)

######
data$Age_group <- ifelse(data$Age < 60,'< 60','≥ 60')
data$PIR_group <- '1.30–3.50'
data$PIR_group[which(data$PIR < 1.3)] <- '<1.30'
data$PIR_group[which(data$PIR >= 3.50)] <- '>= 3.50'
data$PIR_group <- factor(data$PIR_group,levels = c('<1.30','1.30–3.50','>= 3.50'),ordered = T)

data$Marry <- as.character(data$Marry)
table(data$Marry)
data$Marry <- ifelse(data$Marry == 'yes','Married','Never-married')
data$Drink <- as.character(data$Drink)
data$Drink <- ifelse(data$Drink == 'yes','Drinking','Non-drinking')
data$breast <- factor(data$breast,levels = c(0,1),labels = c('Control','Breast cancer'))
data$HF <- as.character(data$HF)
data$HF <- factor(data$HF,levels = c('Heart_failure','Health'),labels = c('Heart Failure','Health'),ordered = T)

data <- subset(data,select = c("breast","Age",'Age_group',"Race","Edu","PIR_group","Marry","Drink",
                               "Hypertension","Diabetes","CHD","HF","WWI"))

library(tableone)
## PS matching
library(Matching)
## Weighted analysis
library(survey)
library(reshape2)
library(ggplot2)
library(tidyverse)

data$breast <- ifelse(data$breast == 'Control',0,1)

#### Propensity score matching ######## Propensity score matching ####data_table01

psModel <- glm(formula = breast ~ Age_group +  Race+ PIR_group,
               family  = binomial(link = "logit"),
               data    = data)

## Predicted probability of being assigned to RHC
data$pRhc <- predict(psModel, type = "response")
## Predicted probability of being assigned to no RHC
data$pNoRhc <- 1 - data$pRhc

## Predicted probability of being assigned to the
## treatment actually assigned (either RHC or no RHC)

# data$breast <- as.character(data$breast)

table(data$breast)

for (i in 1:40) {
  
  set.seed(i)
  
  listMatch <- Match(Tr       = (data$breast == 1),      # Need to be in 0,1
                     ## logit of PS,i.e., log(PS/(1-PS)) as matching scale
                     X        = log(data$pRhc / data$pNoRhc),
                     ## 1:1 matching
                     M        = 1,
                     # caliper = 0.2 * SD(logit(PS))
                     # caliper  = 0.2,
                     distance.tolerance = 1e-04,
                     replace  = FALSE,
                     ties     = TRUE,
                     version  = "fast")
  
  ## Extract matched data
  rhcMatched <- data[unlist(listMatch[c("index.treated","index.control")]), ]
  
  rhcMatched$breast <- ifelse(rhcMatched$breast == 1 , 'Breast cancer','Control')
  
  rhcMatched$breast <- factor(rhcMatched$breast,levels = c('Control','Breast cancer'),ordered = T)
  
  rhcMatched <- rhcMatched[,-c(15,14) ]
  
  colnames(rhcMatched)
  colnames(rhcMatched)[2] <- 'Age, years'
  colnames(rhcMatched)[3] <- 'Age, n(%)'
  colnames(rhcMatched)[4] <- 'Race, n(%)'
  colnames(rhcMatched)[5] <- 'Education, n(%)'
  colnames(rhcMatched)[6] <- 'Poverty-to-income ratio, n(%)'
  colnames(rhcMatched)[7] <- 'Marital status, n(%)'
  colnames(rhcMatched)[8] <- 'Alcohol drinking, n (%)'
  colnames(rhcMatched)[9] <- 'Hypertension, n (%)'
  colnames(rhcMatched)[10] <- 'Diabetes, n (%)'
  colnames(rhcMatched)[11] <- 'CHD, n (%)'
  colnames(rhcMatched)[12] <- 'Heart Failure, n (%)'
  
  tb_psm <- rhcMatched %>%
    tbl_summary(by = breast,
                statistic = list(
                  all_continuous() ~ "{mean} ({sd})", #连续变量
                  all_categorical() ~ "{n} ({p}%)"   #分类变量
                )) %>%
    add_p(pvalue_fun = ~ style_pvalue(.x, digits = 2)) %>% #指定了P值的显示格式为保留两位小数
    add_overall() %>%  #添加总体统计信息
    add_n() %>%  #添加样本量
    modify_header(label ~ "**Variable**") %>% #修改表头标签格式
    # modify_spanning_header(c("stat_1", "stat_2") ~ "**After PSM**") %>%  #合并列头
    modify_footnote(  #添加脚注说明数据格式
      all_stat_cols() ~ "Mean (sd) or Frequency (%)"
    ) %>%
    modify_caption("**Table S1. Baseline characteristics of participants by breast cancer status After PSM**") %>% #修改表格标题
    bold_labels()
  
  if(tb_psm$table_body$p.value[1] > 0.05 & tb_psm$table_body$p.value[length(tb_psm$table_body$p.value)] < 0.05){
    
    print(i)
    
    break
    
  }
  
}

print(tb_psm)

save(rhcMatched,file = 'D03_PsmMatched.RData')

