d <- ttt
cat("原始 n =", nrow(d),
    "| breast:", paste(names(table(d$breast)), table(d$breast), sep="=", collapse="  "), "\n")

## ---- 1. 排除女性生物学不可能的激素值 (行级 OR) ----
excl <- with(d, E2 > 1000 | TT > 200)
cat(sprintf("排除 E2>1000|TT>200 共 %d 行 (E2>1000=%d, TT>200=%d)\n",
            sum(excl), sum(d$E2>1000), sum(d$TT>200)))
d <- d[!excl, ]
cat("排除后 n =", nrow(d), "\n")
cat("  breast:", paste(names(table(d$breast)), table(d$breast), sep="=", collapse="  "), "\n\n")

## ---- 2. 协变量重命名 + 因子化 (age 保持连续) ----
map <- c("Age, years"="age","Race, n(%)"="race",
         "Poverty-to-income ratio, n(%)"="pir",
         "Hypertension, n (%)"="htn","Diabetes, n (%)"="dm","CHD, n (%)"="chd")
for (old in names(map)) names(d)[names(d)==old] <- map[old]
for (v in map) d[[v]] <- as.factor(d[[v]])
cv <- "age + race + pir + htn + dm + chd"

## ---- 3. survey design (Overall + Control 子集) ----
des      <- svydesign(id = ~SDMVPSU, strata = ~SDMVSTRA,
                      weights = ~I(WTMEC2YR/2), nest = TRUE, data = d)
des_ctrl <- subset(des, breast == "Control")
cat("设计自由度 degf(Overall)=", degf(des),
    " degf(Control)=", degf(des_ctrl), "\n\n")

## ---- 4. 单加权回归: β/SE/95%CI(设计自由度 t)/P/未加权 n ----
run_one <- function(des, expr) {
  m <- svyglm(as.formula(paste(expr, "~ WWI +", cv)), design = des)
  s <- summary(m)$coef
  beta <- s["WWI",1]; se <- s["WWI",2]; df <- degf(des)
  tval <- beta/se
  ci <- beta + c(-1,1) * qt(0.975, df) * se
  P <- 2 * pt(-abs(tval), df)   # survey 标准 Wald P: t 分布 + 设计自由度
  data.frame(beta=beta, SE=se, lo=ci[1], hi=ci[2], P=P, n=nrow(des$variables))
}
fp <- function(p) ifelse(p<0.001, "<0.001", sprintf("%.3f", p))

## ---- 5. 5 结局 × (Overall, Control) ----
outs <- c(E2="E2", TT="TT", SHBG="SHBG", `TT/E2`="I(TT/E2)", `TT/SHBG`="I(TT/SHBG)")
cat(sprintf("%-7s | %-40s | %-40s\n", "Outcome",
            "Overall: β(SE) [95%CI], P  [n]", "Control: β(SE) [95%CI], P  [n]"))
cat(paste(rep("-", 86), collapse=""), "\n")
res <- list()
for (nm in names(outs)) {
  o <- run_one(des,      outs[nm])
  c <- run_one(des_ctrl, outs[nm])
  res[[nm]] <- list(Overall=o, Control=c)
  cat(sprintf("%-7s | β=%+8.3f(%5.3f) [%+8.3f,%+8.3f] P=%-6s[n=%d] | β=%+8.3f(%5.3f) [%+8.3f,%+8.3f] P=%-6s[n=%d]\n",
      nm, o$beta, o$SE, o$lo, o$hi, fp(o$P), o$n,
           c$beta, c$SE, c$lo, c$hi, fp(c$P), c$n))
}

## ---- 6. 未加权 lm 对照 (确认加权带来的 SE 膨胀) ----
cat("\n=== 未加权 lm 对照 (Overall) ===\n")
for (nm in names(outs)) {
  m <- lm(as.formula(paste(outs[nm], "~ WWI +", cv)), data=d)
  s <- summary(m)$coef; ci <- confint(m,"WWI")
  cat(sprintf("%-7s β=%+-8.3f SE=%.3f (%+7.3f,%+7.3f) P=%s [n=%d]\n",
      nm, s["WWI",1], s["WWI",2], ci[1], ci[2], fp(s["WWI",4]), nobs(m)))
}

cat("\nDONE_T3W\n")
