
rm(list = ls()); gc()
suppressPackageStartupMessages({ library(xgboost); library(shapviz); library(patchwork); library(ggplot2) })

set.seed(20241115)

load(file.path(WORK_DIR, "D02_CleanData_Before_PSM.RData"))
stopifnot(exists("data"))
data <- data[, -2]
colnames(data)[c(c(2, 3, 5:11))] <- c(
  "Age", "Race", "PIR", "Marital", "Alcohol",
  "Hypertension", "Diabetes", "CHD", "HeartFailure")
data$breast <- as.numeric(data$breast)
data$breast <- ifelse(data$breast == 1, 0, 1)
data$Age <- as.numeric(factor(data$Age, levels = c("< 60", "≥ 60"), labels = c(0, 1)))
data$Race <- as.numeric(factor(data$Race, levels = c("non_Hispanic_White", "non_Hispanic_Black",
             "Mexican_American", "Other_Hispanic", "Others"), labels = c(1:5)))
data$PIR <- as.numeric(factor(data$PIR, levels = c("<1.30", "1.30–3.50", ">= 3.50"), labels = c(1, 2, 3)))
data$Marital <- as.numeric(factor(data$Marital, levels = c("Married", "Never-married"), labels = c(1, 0)))
data$Alcohol <- as.numeric(factor(data$Alcohol, levels = c("Drinking", "Non-drinking"), labels = c(1, 0)))
data$Hypertension <- as.numeric(factor(data$Hypertension, levels = c("Hypertension", "Health"), labels = c(1, 0)))
data$Diabetes <- as.numeric(factor(data$Diabetes, levels = c("Diabetes", "Health"), labels = c(1, 0)))
data$CHD <- as.numeric(factor(data$CHD, levels = c("CHD", "Health"), labels = c(1, 0)))
data$HeartFailure <- as.numeric(factor(data$HeartFailure, levels = c("Heart Failure", "Health"), labels = c(1, 0)))
data$WWI_Group <- "Q"
data$WWI_Group[which(data$WWI < as.numeric(quantile(data$WWI))[2])] <- "Q1"
data$WWI_Group[which(data$WWI >= as.numeric(quantile(data$WWI))[2] &
                     data$WWI <  as.numeric(quantile(data$WWI))[3])] <- "Q2"
data$WWI_Group[which(data$WWI >= as.numeric(quantile(data$WWI))[3] &
                     data$WWI <  as.numeric(quantile(data$WWI))[4])] <- "Q3"
data$WWI_Group[which(data$WWI >= as.numeric(quantile(data$WWI))[4])] <- "Q4"
data$WWI_Group <- factor(data$WWI_Group, levels = c("Q1", "Q2", "Q3", "Q4"))
data$WWI_Num <- as.numeric(data$WWI_Group)
X <- data[, c(2, 3, 5, 6, 7, 8, 9, 10, 11, 12)]
xvars <- colnames(X)
cat("n =", nrow(X), "| features:", paste(xvars, collapse = ", "), "\n")
cat("events =", sum(data$breast), "\n")

# ---------- 3. 训练(与发表管线完全一致:默认 objective,lr 0.05, 6 轮) ----------
fit <- xgb.train(params = list(learning_rate = 0.05),
                 data = xgb.DMatrix(data.matrix(X), label = data$breast),
                 nrounds = 6)

# ---------- [A] 复现:seed 后第一次 sample = 发表版 2,000 子样本 ----------
get_imp <- function(s) {
  sv <- shapviz::get_shap_values(s)
  colMeans(abs(sv[, xvars, drop = FALSE]))
}
as_tab <- function(v) data.frame(Feature = names(v)[order(-v)], mean_abs_SHAP = sort(v, decreasing = TRUE))

X_explain <- X[sample(nrow(X), 2000), ]
shp <- shapviz(fit, X_pred = data.matrix(X_explain), X = X_explain)
imp_repro <- as_tab(get_imp(shp))
cat("\n[A] REPRODUCTION (published pipeline, seed 20241115, n=2000):\n")
print(imp_repro, digits = 5)
write.csv(imp_repro, file.path(OUT_DIR, "R4_C04z_A_importance_published.csv"), row.names = FALSE)

# ---------- [B] 全队列 SHAP ----------
shp_full <- shapviz(fit, X_pred = data.matrix(X), X = X)
val_full <- get_imp(shp_full)
imp_full <- as_tab(val_full)
cat("\n[B] FULL-COHORT SHAP (n=6,782, no subsampling):\n")
print(imp_full, digits = 5)
write.csv(imp_full, file.path(OUT_DIR, "R4_C04z_B_importance_fullcohort.csv"), row.names = FALSE)
val_full <- get_imp(shp_full)
rank_full <- rank(-val_full)

r_explain <- r_refit <- matrix(NA_real_, 10, 10, dimnames = list(xvars, paste0("s", 1:10)))
for (i in 1:10) {
  set.seed(20241115 + i)
  idx <- sample(nrow(X), 2000)
  Xe <- X[idx, ]
  # (C1) 固定模型,解释集换 10 个种子
  si <- shapviz(fit, X_pred = data.matrix(Xe), X = Xe)
  r_explain[, i] <- get_imp(si)
  # (C2) 子样本重训,全队列解释
  mf <- xgb.train(params = list(learning_rate = 0.05),
                  data = xgb.DMatrix(data.matrix(Xe), label = data$breast[idx]), nrounds = 6)
  sf <- shapviz(mf, X_pred = data.matrix(X), X = X)
  r_refit[, i] <- get_imp(sf)
}
rank_e <- apply(r_explain, 2, function(v) rank(-v)); rank_r <- apply(r_refit, 2, function(v) rank(-v))
S7 <- data.frame(Feature = xvars,
  mean_abs_SHAP_published = imp_repro$mean_abs_SHAP[match(xvars, imp_repro$Feature)],
  mean_abs_SHAP_full      = val_full[xvars],
  rank_full               = rank_full[xvars],
  explain_rank_min = apply(rank_e, 1, min), explain_rank_max = apply(rank_e, 1, max),
  refit_rank_min   = apply(rank_r, 1, min), refit_rank_max   = apply(rank_r, 1, max))
S7 <- S7[order(S7$rank_full), ]
cat("\n[C] S7 stability table:\n"); print(S7, digits = 4)
write.csv(S7, file.path(OUT_DIR, "R4_C04z_C_S7_stability.csv"), row.names = FALSE)

