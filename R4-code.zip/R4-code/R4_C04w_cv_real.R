

set.seed(20241115)

data <- data[, -2]
colnames(data)[c(c(2, 3, 5:11))] <- c("Age","Race","PIR","Marital","Alcohol","Hypertension","Diabetes","CHD","HeartFailure")
data$breast <- as.numeric(data$breast); data$breast <- ifelse(data$breast == 1, 0, 1)
data$Age <- as.numeric(factor(data$Age, levels = c("< 60","≥ 60"), labels = c(0,1)))
data$Race <- as.numeric(factor(data$Race, levels = c("non_Hispanic_White","non_Hispanic_Black","Mexican_American","Other_Hispanic","Others"), labels = c(1:5)))
data$PIR <- as.numeric(factor(data$PIR, levels = c("<1.30","1.30–3.50",">= 3.50"), labels = c(1,2,3)))
data$Marital <- as.numeric(factor(data$Marital, levels = c("Married","Never-married"), labels = c(1,0)))
data$Alcohol <- as.numeric(factor(data$Alcohol, levels = c("Drinking","Non-drinking"), labels = c(1,0)))
data$Hypertension <- as.numeric(factor(data$Hypertension, levels = c("Hypertension","Health"), labels = c(1,0)))
data$Diabetes <- as.numeric(factor(data$Diabetes, levels = c("Diabetes","Health"), labels = c(1,0)))
data$CHD <- as.numeric(factor(data$CHD, levels = c("CHD","Health"), labels = c(1,0)))
data$HeartFailure <- as.numeric(factor(data$HeartFailure, levels = c("Heart Failure","Health"), labels = c(1,0)))
data$WWI_Group <- "Q"; q <- as.numeric(quantile(data$WWI))
data$WWI_Group[which(data$WWI < q[2])] <- "Q1"
data$WWI_Group[which(data$WWI >= q[2] & data$WWI < q[3])] <- "Q2"
data$WWI_Group[which(data$WWI >= q[3] & data$WWI < q[4])] <- "Q3"
data$WWI_Group[which(data$WWI >= q[4])] <- "Q4"
X <- data[, c(2, 3, 5, 6, 7, 8, 9, 10, 11, 12)]; Xm <- data.matrix(X); y <- data$breast
set.seed(11); folds <- sample(rep(1:10, length.out = nrow(Xm)))
auc <- matrix(NA_real_, 50, 10)
for (k in 1:10) {
  tr <- folds != k; te <- !tr
  m <- xgb.train(params = list(learning_rate = 0.05),
                 data = xgb.DMatrix(Xm[tr,,drop=FALSE], label = y[tr]), nrounds = 50)
  Dte <- xgb.DMatrix(Xm[te,,drop=FALSE])
  auc[,k] <- sapply(1:50, function(r) as.numeric(pROC::roc(y[te], predict(m, Dte, ntreelimit=r), quiet=TRUE, direction="<", levels=c(0,1))$auc))
}
tab <- data.frame(nrounds = 1:50, auc_mean = rowMeans(auc), auc_sd = apply(auc,1,sd))
best <- which.max(tab$auc_mean)
cat(sprintf("CV(real pipeline): best AUC %.4f at nrounds=%d | AUC@6 = %.4f (sd %.4f) | AUC@50 = %.4f\n",
    tab$auc_mean[best], best, tab$auc_mean[6], tab$auc_sd[6], tab$auc_mean[50]))
write.csv(tab, "R4_C04w_CV_curve_real.csv", row.names = FALSE)
cat("DONE\n")
