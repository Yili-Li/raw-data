
map <- c("Age, years"="age","Race, n(%)"="race",
         "Poverty-to-income ratio, n(%)"="pir",
         "Hypertension, n (%)"="htn","Diabetes, n (%)"="dm","CHD, n (%)"="chd")
for (old in names(map)) names(d)[names(d)==old] <- map[old]
for (v in map) d[[v]] <- as.factor(d[[v]])
cv <- "age + race + pir + htn + dm + chd"

## ---- 2. survey design ----
des      <- svydesign(id=~SDMVPSU, strata=~SDMVSTRA,
                      weights=~I(WTMEC2YR/2), nest=TRUE, data=d)
des_ctrl <- subset(des, breast=="Control")
d_ctrl   <- subset(d, breast=="Control")

## ---- 3. 两种回归器 ----
run_w <- function(des, expr){           # 加权 svyglm
  m <- svyglm(as.formula(paste(expr,"~ WWI +",cv)), design=des)
  s <- summary(m)$coef; beta<-s["WWI",1]; se<-s["WWI",2]; df<-degf(des)
  ci<-beta+c(-1,1)*qt(0.975,df)*se; P<-2*pt(-abs(beta/se),df)
  list(beta=beta,se=se,lo=ci[1],hi=ci[2],P=P,n=nrow(des$variables))
}
run_u <- function(dat, expr){           # 未加权 lm
  m <- lm(as.formula(paste(expr,"~ WWI +",cv)), data=dat)
  s <- summary(m)$coef; ci<-confint(m,"WWI")
  list(beta=s["WWI",1],se=s["WWI",2],lo=ci[1],hi=ci[2],P=s["WWI",4],n=nobs(m))
}

## ---- 4. 整理成表 ----
outs  <- c(E2="E2",TT="TT",SHBG="SHBG",`TT/E2`="I(TT/E2)",`TT/SHBG`="I(TT/SHBG)")
units <- c(E2="pg/mL",TT="ng/dL",SHBG="nmol/L",`TT/E2`="ratio",`TT/SHBG`="ratio")
fp <- function(p) ifelse(p<0.001,"<0.001",sprintf("%.3f",p))
fmt <- function(r) sprintf("%+.3f (%+.3f, %+.3f), P=%s", r$beta, r$lo, r$hi, fp(r$P))

build <- function(F){
  rows <- list()
  for(nm in names(outs)){
    o <- F(des, d, outs[nm]); c <- F(des_ctrl, d_ctrl, outs[nm])
    rows[[nm]] <- data.frame(
      Hormone=nm, Unit=units[nm],
      Overall_beta=round(o$beta,3), Overall_SE=round(o$se,3),
      Overall_CI=sprintf("[%.3f, %.3f]",o$lo,o$hi), Overall_P=fp(o$P), Overall_n=o$n,
      Overall_display=fmt(o),
      Control_beta=round(c$beta,3), Control_SE=round(c$se,3),
      Control_CI=sprintf("[%.3f, %.3f]",c$lo,c$hi), Control_P=fp(c$P), Control_n=c$n,
      Control_display=fmt(c), stringsAsFactors=FALSE)
  }
  do.call(rbind, rows)
}

res_w <- build(function(des,dat,e) run_w(des,e))
res_u <- build(function(des,dat,e) run_u(dat,e))



