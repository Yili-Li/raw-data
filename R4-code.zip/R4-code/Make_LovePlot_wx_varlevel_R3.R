
cat(sprintf("[1] Pre-PSM  n = %d (cases = %d, controls = %d)\n",
            nrow(pre), sum(pre$breast == "Breast cancer"),
            sum(pre$breast == "Control")))
cat(sprintf("    Post-PSM n = %d (cases = %d, controls = %d)\n\n",
            nrow(post), sum(post$breast == "Breast cancer"),
            sum(post$breast == "Control")))

# ---------- 1b. R3: collapse education 5 -> 4 categories ----------
collapse_edu <- function(x) {
  x <- as.character(x)
  x[x %in% c("LessThan9thGrade", "9_11thGrade")] <- "LessThan11thGrade"
  factor(x, levels = c("LessThan11thGrade", "High_School",
                       "AA_Degree", "College_Graduate"))
}
pre[["Education, n(%)"]]  <- collapse_edu(pre[["Education, n(%)"]])
post[["Education, n(%)"]] <- collapse_edu(post[["Education, n(%)"]])

cat("[1b] Education after collapse (R3, 4 levels):\n")
cat("     Pre-PSM:\n");  print(table(pre[["Education, n(%)"]]))
cat("     Post-PSM by group:\n")
print(table(post[["Education, n(%)"]], post$breast))
cat("     Expected (Table S5): LessThan11thGrade 88 (49/39), High_School 93 (52/41),\n")
cat("                          AA_Degree 122 (57/65), College_Graduate 113 (50/63)\n\n")

# ---------- 2. Variable definitions (aligned with Table S5) ----------
factor_vars <- c("Age, n(%)", "Race, n(%)", "Education, n(%)",
                 "Poverty-to-income ratio, n(%)", "Marital status, n(%)",
                 "Alcohol drinking, n (%)", "Hypertension, n (%)",
                 "Diabetes, n (%)", "CHD, n (%)", "Heart Failure, n (%)")
all_vars <- c("Age, years", "WWI", factor_vars)


# ---------- 3. Compute variable-level SMD via tableone ----------
compute_var_smd <- function(df) {
  tab <- CreateTableOne(vars = all_vars, factorVars = factor_vars,
                        strata = "breast", data = df,
                        test = FALSE, smd = TRUE)
  smd_mat <- ExtractSmd(tab)         # matrix 12 x 1 with rownames = variables
  out <- setNames(as.numeric(smd_mat[, 1]), rownames(smd_mat))
  return(out[all_vars])              # enforce order
}

smd_pre  <- compute_var_smd(pre)
smd_post <- compute_var_smd(post)

smd_df <- data.frame(
  Variable = names(smd_pre),
  Label    = var_labels[names(smd_pre)],
  SMD_pre  = as.numeric(smd_pre),
  SMD_post = as.numeric(smd_post),
  row.names = NULL,
  stringsAsFactors = FALSE
)

# Mark variable type for plotting
smd_df$Type <- ifelse(smd_df$Variable %in% c("Age, years", "WWI"),
                      "Continuous", "Categorical")

# Order by |pre-SMD| desc (largest imbalance at top, cobalt style)
smd_df$abs_pre <- abs(smd_df$SMD_pre)
smd_df <- smd_df[order(-smd_df$abs_pre), ]
smd_df$Label <- factor(smd_df$Label, levels = rev(smd_df$Label))

cat("[2] Variable-level SMD (sorted by |pre-PSM SMD|):\n\n")
print(smd_df[, c("Variable", "Label", "Type", "SMD_pre", "SMD_post")],
      row.names = FALSE, digits = 3)

cat(sprintf("\n[3] Variables with |post-SMD| > 0.1: %d / %d\n",
            sum(abs(smd_df$SMD_post) > 0.1), nrow(smd_df)))

cat("\n[4] Cross-check vs Table S5, R3 education 4-level (|post-SMD|):\n")
cat(sprintf("  %-32s  %-10s  %-10s  %s\n",
            "Variable", "This run", "Table S5", "Match?"))
for (v in all_vars) {
  this_val <- abs(smd_df$SMD_post[smd_df$Variable == v])
  s5_val   <- table_s5_ref[v]
  diff     <- abs(this_val - s5_val)
  flag <- if (diff < 0.005) "OK" else sprintf("DIFF=%.3f", diff)
  cat(sprintf("  %-32s  %-10.4f  %-10.3f  %s\n",
              var_labels[v], this_val, s5_val, flag))
}

# ---------- 4. Save CSV ----------
write.csv(smd_df[, c("Variable", "Label", "Type", "SMD_pre", "SMD_post")],
          file.path(WORK_DIR, "Figure S2.PSM_LovePlot_wx_varlevel.csv"),
          row.names = FALSE)
cat(sprintf("\n[5] Underlying SMD table saved: Figure S2.PSM_LovePlot_wx_varlevel.csv\n"))

# ---------- 5. Variable-level Love plot ----------
plot_df <- data.frame(
  Label   = rep(smd_df$Label, 2),
  abs_SMD = c(abs(smd_df$SMD_pre), abs(smd_df$SMD_post)),
  Sample  = factor(rep(c("Pre-PSM", "Post-PSM"), each = nrow(smd_df)),
                   levels = c("Pre-PSM", "Post-PSM"))
)

x_max <- ceiling(max(plot_df$abs_SMD) * 11) / 10  # round to 0.1
brks  <- seq(0, x_max, by = 0.1)

p <- ggplot(plot_df, aes(x = abs_SMD, y = Label,
                         color = Sample, fill = Sample, shape = Sample)) +
  geom_vline(xintercept = 0.1, linetype = "dashed",
             color = "#C00000", linewidth = 0.6) +
  geom_vline(xintercept = 0, linetype = "solid",
             color = "grey70", linewidth = 0.3) +
  geom_line(aes(group = Label),
            color = "grey60", linewidth = 0.4) +
  geom_point(size = 4, stroke = 0.8) +
  scale_color_manual(values = c("Pre-PSM" = "#E69F00",
                                "Post-PSM" = "#0072B2")) +
  scale_fill_manual(values  = c("Pre-PSM" = "#E69F00",
                                "Post-PSM" = "#0072B2")) +
  scale_shape_manual(values = c("Pre-PSM" = 21, "Post-PSM" = 21)) +
  scale_x_continuous(limits = c(0, x_max), breaks = brks) +
  labs(title = "Covariate balance before and after propensity score matching",
       subtitle = "Variable-level absolute SMD (|SMD|); dashed line = 0.1 threshold (Austin 2009); n = 12 covariates",
       x = "Absolute standardized mean difference (|SMD|)",
       y = NULL,
       color = NULL, shape = NULL, fill = NULL) +
  theme_bw(base_size = 12) +
  theme(
    plot.title    = element_text(face = "bold", hjust = 0, size = 13),
    plot.subtitle = element_text(size = 10, color = "grey30", hjust = 0),
    axis.text.y   = element_text(size = 11),
    axis.text.x   = element_text(size = 10),
    axis.title.x  = element_text(size = 11),
    legend.position  = "bottom",
    legend.title     = element_blank(),
    legend.text      = element_text(size = 11),
    panel.grid.major.x = element_line(color = "grey90", linewidth = 0.3),
    panel.grid.minor.x = element_blank(),
    panel.grid.major.y = element_blank(),
    plot.margin = margin(t = 12, r = 15, b = 8, l = 10)
  )

out_png <- file.path(WORK_DIR, "Figure S2.PSM_LovePlot_wx_varlevel.png")
ggsave(out_png, p, width = 10, height = 6, dpi = 300, units = "in")
cat(sprintf("\n[6] Love plot saved: %s\n", out_png))

out_pdf <- file.path(WORK_DIR, "Figure S2.PSM_LovePlot_wx_varlevel.pdf")
ggsave(out_pdf, p, width = 10, height = 6, units = "in")
cat(sprintf("[7] PDF (vector) saved: %s\n", out_pdf))

cat("\n============================================================\n")
cat("DONE.\n")
cat("============================================================\n")
