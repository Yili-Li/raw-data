rm(list = ls())
gc()
# setwd('/Users/hopestar/PHD_database_bk/Other_analysis/JLX_ToC_Project/Project59-CYMX-ER+乳腺癌-1A(3)-NO.GG.20241016274231021319/Step05_SubGroup')
script_path <- normalizePath(dirname(rstudioapi::getActiveDocumentContext()$path))  # 获取当前文件目录 by dyy
setwd(script_path) # 设定当前文件目录为工作路径
library(jstable)      
library(survival)     
library(dplyr)         
library(openxlsx)  
library('foreign')
library('ggplot2')
library('rms')
library('survival')
library('Hmisc')
library('splines')
library(smoothHR)
library(survival)
#library(rms) # 用于产生限制性三次样条
library(Hmisc) # 用于产生限制性三次样条（推荐，参数更精确）
library(ggrcs)
library(rms)
library(ggplot2)
library(scales)
library(cowplot)
library(survey)
library(foreign)

Sys.setenv(LANGUAGE = "en") #显示英文报错信息
options(stringsAsFactors = FALSE) #禁止chr转成factor


data <- data[,-2]
colnames(data)[2:12] <- c('Age','Race','Education','PIR','Marital','Alcohol','Hypertension','Diabetes','CHD','HeartFailure','WWI')

data$breast <- ifelse(data$breast == 'Control',0,1)

data2 <- data;rm(data)

## factor 01 ##

data2$WWI_Group <- 'Q'
data2$WWI_Group[which(data2$WWI < as.numeric(quantile(data2$WWI))[2])] <- 'Q1'
data2$WWI_Group[which(data2$WWI >= as.numeric(quantile(data2$WWI))[2] & data2$WWI < as.numeric(quantile(data2$WWI))[3])] <- 'Q2'
data2$WWI_Group[which(data2$WWI >= as.numeric(quantile(data2$WWI))[3] & data2$WWI < as.numeric(quantile(data2$WWI))[4])] <- 'Q3'
data2$WWI_Group[which(data2$WWI >= as.numeric(quantile(data2$WWI))[4])] <- 'Q4'
table(data2$WWI_Group)
data2$WWI_Group <- factor(data2$WWI_Group,levels = c('Q1','Q2','Q3','Q4'))
data2$WWI_Num <- as.numeric(data2$WWI_Group)
str(data2)

summary(data2$Age)

# var_subgroups <- colnames(data2)[c(2,3,4,5,6)]
var_subgroups <- colnames(data2)[c(8,9,10,11)]
var_cov <- NULL

# 调用 TableSubgroupMultiGLM 函数进行多组 logistic 回归分析
res <- TableSubgroupMultiGLM(formula = breast ~ WWI_Group,
                             var_subgroups = var_subgroups,#亚组
                             var_cov = var_cov,#协变量
                             family = "binomial",  # 指定回归模型为二项分布
                             data = data2)


# 输出结果
print(res)

# res <- res[-c(36:39),]

# 将可能存在的NA值替换为空字符串或其他值
res[is.na(res)] <- ""

rt <- print(res)

rt$Count[which(rt$Count != '')] <- paste0(rt$Count[which(rt$Count != '')],'(',rt$Percent[which(rt$Percent != '')],'%)')
rt$tmp <- ''
rt$tmp[which(rt$OR != '' & rt$OR != 'Reference')] <- paste0(rt$OR[which(rt$OR != '' & rt$OR != 'Reference')],
                                                            '(',rt$Lower[which(rt$OR != '' & rt$OR != 'Reference')],'-',
                                                            rt$Upper[which(rt$OR != '' & rt$OR != 'Reference')],')')

colnames(rt)[ncol(rt)] <- 'OR.(95%CI)'
colnames(rt)[2] <- 'Events'
colnames(rt)[1] <- 'Subgroup'
colnames(rt)[c(8,9)] <- c('P.value','P.for.interaction')

colnames(rt)

rt <- subset(rt,select = c('Subgroup','Events','OR','Lower','Upper','Levels','OR.(95%CI)','P.value','P.for.interaction'))


library(data.table)
library(openxlsx)
library(dplyr)
library(ggplot2)
library(forestploter)
library(grid)

dt <- rt

dt$`Subgroup1` <- paste(rep(" ", max(nchar(dt$Subgroup))), collapse = " ")

colnames(dt)
dt <- dt[, c("Subgroup", "Events", "OR", "Lower", "Upper", "Subgroup1", 'Levels',
             "OR.(95%CI)", "P.value", "P.for.interaction")]

dt1 <- dt[, c("Subgroup", "Events", "OR", "Lower", "Upper", 'Levels',
              "OR.(95%CI)", "P.value", "P.for.interaction")]
dt1

# 处理没有数据的位置，将 NA 转换为 " "
dt$Subgroup <- ifelse(is.na(dt$OR), dt$Subgroup, paste0("   ", dt$Subgroup))  # 如果OR列为NA，则保持X1列不变，否则在X1前添加空格
dt$`Event` <- ifelse(is.na(dt$`Event`), "", dt$`Event`)  # 如果Event列为NA，则替换为""（空字符串）
dt$OR <- ifelse(is.na(dt$OR), "", dt$OR)  # 如果OR列为NA，则替换为""（空字符串）
dt$`OR.(95%CI)` <- ifelse(is.na(dt$`OR.(95%CI)`), "", dt$`OR.(95%CI)`)  # 如果OR(95%CI)列为NA，则替换为""（空字符串）
dt$P.value <- ifelse(is.na(dt$P.value), "", dt$P.value)  # 如果P.value列为NA，则替换为""（空字符串）
dt$P.for.interaction <- ifelse(is.na(dt$P.for.interaction), "", dt$P.for.interaction)  # 如果P.for.interaction列为NA，则替换为""（空字符串）

# 确保 OR、Lower、Upper 的数据列为数值型
dt[, c("OR", "Lower", "Upper")] <- lapply(dt[, c("OR", "Lower", "Upper")], as.numeric)  

#####开始画图
tm <- forest_theme(
  base_size = 12,                          # 设置基础字体大小为12
  refline_gp = gpar(lty = "dashed", col = "black"),  # 将参考线设置为虚线，颜色为黑色
  ci_pch = c(15),                          # 设置置信区间点的符号类型为实心方形
  ci_col = "black",                        # 设置置信区间线的颜色为黑色
  ci_alpha = 0.8,                          # 设置置信区间线的透明度为0.8
  ci_lty = 1,                              # 设置置信区间线的线型为实线
  ci_lwd = 1.5,                            # 设置置信区间线的宽度为1.5
  ci_Theight = 0,                          # 设置置信区间线的T型线高度为0
  vertline_lty = c("dashed", "dotted"),    # 设置垂直参考线的线型为虚线和点线
  vertline_col = c("#d6604d", "#bababa")   # 设置垂直参考线的颜色分别为红色和灰色
)

p <- forest(
  dt[, c("Subgroup", "Event", "Subgroup1", 'Levels',"OR.(95%CI)", "P.value", "P.for.interaction")],  # 包含亚组信息和置信区间
  est = list(dt$OR),                  # 设置效应值列，分别为HR和HR1
  lower = list(dt$Lower),    # 设置置信区间下限列
  upper = list(dt$Upper),  # 设置置信区间上限列
  ci_column = c(3),                        # 指定森林图在第3列绘制置信区间
  sizes = 0.6,                                # 设置置信区间符号的大小
  ref_line = 1,                               # 设置参考线位置
  arrow_lab = c("Decreased Risk for BreastCancer", 
                "Increased Risk for BreastCancer"), # 设置箭头标签，分别为"Decreased Risk"和"Increased Risk"
  xlim = c(-1, 3),                         # 设置x轴的限制范围
  ticks_at = c(0, 1, 2, 3),        # 设置x轴上的刻度位置
  arrow_length = 4,                           # 设置箭头的长度为4
  theme = tm                                  # 使用之前配置的主题
)

add_underline <- function(text) {
  underline <- strrep("-", nchar(p))  # 创建与文本长度相同的下划线
  cat(p, "\n", underline, "\n")       # 打印文本并添加下划线
}

# 设置指定行的字体为粗体
# p <- edit_plot(p, row = c(1, 2,11,20,29,38), gp = gpar(fontface = "bold"))

dev.off()
pdf("Figure subgroup analysis WWI Part II.pdf", height = 20, width = 12)
plot(p)
dev.off()

save(dt,file = 'D01_dt_PartII.RData')













